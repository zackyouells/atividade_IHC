# atividade_IHC
Refatoração do site criacaodesitesbaratos, conforme as boas práticas da disciplina de IHC.
